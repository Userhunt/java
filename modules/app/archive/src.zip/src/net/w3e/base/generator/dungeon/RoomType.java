package net.w3e.base.generator.dungeon;

import net.w3e.base.generator.PropertyType;

public class RoomType extends PropertyType {

	public RoomType(String attribute, String id, String... flags) {
		super("dungeon", attribute, id, flags);
	}

	//комната
		//вход
		//выход
		//коридор
		//сундук
		//враг
		//ловушка
		//босс
		//святилище
	
	//тип

	//размер - flag
		//маленький
		//средний
		//большой
}
