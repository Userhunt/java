package net.w3e.base.generator.dungeon;

@Deprecated
public abstract class ArrayDungeonGenerator {
	
}
