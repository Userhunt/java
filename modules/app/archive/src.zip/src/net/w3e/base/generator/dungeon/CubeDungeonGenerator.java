package net.w3e.base.generator.dungeon;

import java.util.List;

public class CubeDungeonGenerator extends DungeonGenerator {

	@Deprecated
	public CubeDungeonGenerator(List<Room> modificators) {
		super(modificators);
	}
}
