package net.w3e.app.utils.tf2;

public interface Tf2IconImpl {
	Tf2RegistryObject self();
	String more(float dollar);
}
